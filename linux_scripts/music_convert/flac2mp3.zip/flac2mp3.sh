#!/bin/bash

/home/asandler/.flac2mp3/flac2mp3.pl $@
